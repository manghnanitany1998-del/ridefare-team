// Vercel serverless function: AI trip insight with Google Gemini.
// The key is read ONLY from the environment (GEMINI_API_KEY); it never reaches the browser.
// Cost controls: cheapest Flash-Lite model, tiny prompt, max 120 output tokens,
// in-memory cache, per-IP rate limit, and a full fallback when no key is set.

const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash-lite";
const MAX_TOKENS = parseInt(process.env.GEMINI_MAX_TOKENS || "120", 10);
const RATE_PER_MIN = parseInt(process.env.AI_RATE_LIMIT_PER_MIN || "6", 10);
const CACHE = new Map();          // key -> {text, t}
const HITS = new Map();           // ip -> [timestamps]
const CACHE_MS = 6 * 60 * 60 * 1000;

function fallback(b) {
  const tips = [];
  if (b.intercity) tips.push("Long trip: book an outstation cab in advance and confirm tolls and driver allowance.");
  if (b.surge > 1) tips.push(`Surge is ${b.surge}x right now; waiting 20-30 minutes may lower the price.`);
  if (b.night) tips.push("Night charge applies between 11 PM and 5 AM.");
  if (b.cheapest_hour) tips.push(`Cheapest time for this trip today: around ${b.cheapest_hour}.`);
  tips.push(`Distance drives the fare: about ${b.rate || "1.86"} per km on top of a small base.`);
  return tips.slice(0, 3).join(" ");
}

module.exports = async (req, res) => {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
  let b = req.body || {};
  if (typeof b === "string") { try { b = JSON.parse(b); } catch { b = {}; } }

  const key = process.env.GEMINI_API_KEY;
  if (!key) return res.status(200).json({ source: "rules", text: fallback(b) });

  const ip = (req.headers["x-forwarded-for"] || "anon").split(",")[0].trim();
  const now = Date.now();
  const hist = (HITS.get(ip) || []).filter(t => now - t < 60000);
  if (hist.length >= RATE_PER_MIN) return res.status(200).json({ source: "rules", text: fallback(b), note: "rate-limited" });
  hist.push(now); HITS.set(ip, hist);

  // Round inputs so similar trips share one cached answer (fewer paid calls)
  const ck = [b.from, b.to, Math.round(b.km || 0), b.ride, b.surge, b.intercity ? 1 : 0, b.hour].join("|");
  const c = CACHE.get(ck);
  if (c && now - c.t < CACHE_MS) return res.status(200).json({ source: "gemini-cache", text: c.text });

  const prompt =
    `You are a concise ride assistant. In max 3 short sentences give practical tips for this trip. ` +
    `No markdown. Trip: ${b.from} to ${b.to}, ${Math.round(b.km)} km, ${b.ride}, fare ${b.fare}, ` +
    `hour ${b.hour}, surge ${b.surge}x, ${b.intercity ? "intercity" : "city"} trip, weather ${b.weather}.`;

  try {
    const r = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": key },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: prompt }] }],
          generationConfig: { maxOutputTokens: MAX_TOKENS, temperature: 0.4 }
        })
      }
    );
    const j = await r.json();
    const text = j?.candidates?.[0]?.content?.parts?.map(p => p.text).join(" ").trim();
    if (!text) return res.status(200).json({ source: "rules", text: fallback(b), note: j?.error?.message || "empty" });
    CACHE.set(ck, { text, t: now });
    if (CACHE.size > 500) CACHE.delete(CACHE.keys().next().value);
    return res.status(200).json({ source: "gemini", text });
  } catch (e) {
    return res.status(200).json({ source: "rules", text: fallback(b), note: "ai-unavailable" });
  }
};
