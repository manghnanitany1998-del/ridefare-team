// RideFare model, exported from the notebook's final model (Linear Regression on distance_km).
// Trained on 42,540 completed trips of uber_trips_dataset_50k.csv, 80/20 split, random_state=42.
// If you retrain, update these numbers from reports/results.json (rate_per_km, base_fare).
window.RIDEFARE_MODEL = {
  name: "Linear Regression (distance_km)",
  base_fare: 2.973,          // intercept, USD
  rate_per_km: 1.857,        // slope, USD per km
  max_train_km: 19.4,        // longest trip in training data
  metrics: { MAE: 2.491, RMSE: 3.103, R2: 0.750, Train_R2: 0.760, CV_RMSE: 3.084, within_2: 48.0 },
  rows: 42540, test_rows: 8508,
  comparison: [
    ["Predict the average", 4.956, 6.208, 0.000],
    ["Linear Regression (distance) - final", 2.491, 3.103, 0.750],
    ["Linear Regression (all features)", 2.491, 3.103, 0.750],
    ["Hist Gradient Boosting*", 2.523, 3.148, 0.747],
    ["XGBoost*", 2.536, 3.169, 0.744],
    ["Random Forest*", 2.596, 3.268, 0.727]
  ],
  importance: { "Distance": 99.9, "Hour": 0.1, "Weekday": 0.0, "Weekend": 0.0, "City": 0.0, "Payment": 0.0 }
};
