/* RideFare front-end. All pricing runs in the browser (free, instant).
   Only the optional AI tip calls the server (/api/insight), which reads GEMINI_API_KEY from env. */
const M = window.RIDEFARE_MODEL;
const $ = id => document.getElementById(id);
let PLACES = [], CUR = {}, RATES = null, AI_ON = false;
let pickup = null, dropoff = null, quote = null, chosen = "Go";
let map, layer;

const RIDES = { Go: [1.0, 4, "🚗", "Affordable compact rides"], Premier: [1.35, 4, "🚙", "Comfortable sedans, top-rated drivers"],
  XL: [1.6, 6, "🚐", "SUVs for groups up to 6"], Auto: [0.6, 3, "🛺", "Auto rickshaw rides"], Moto: [0.45, 1, "🏍️", "Beat traffic on a bike"] };
const NO_INTERCITY = ["Auto", "Moto"];
const OUT_INR = { Go: 12, Premier: 15, XL: 19 };            // ₹ per km, illustrative outstation tariff
const SYM = { USD: "$", INR: "₹", EUR: "€", GBP: "£", JPY: "¥", CNY: "¥", AED: "AED ", SGD: "S$", AUD: "A$", CAD: "C$", CHF: "CHF ", SAR: "SAR ",
  BRL: "R$", ZAR: "R ", KRW: "₩", THB: "฿", MYR: "RM ", IDR: "Rp ", PKR: "Rs ", LKR: "Rs ", BDT: "৳", NPR: "Rs ", RUB: "₽", TRY: "₺", MXN: "MX$", NZD: "NZ$", HKD: "HK$" };
const FALLBACK = { USD: 1, INR: 83, EUR: 0.92, GBP: 0.79, JPY: 150, AED: 3.67, SGD: 1.35, AUD: 1.52, CAD: 1.36, CHF: 0.88, SAR: 3.75, CNY: 7.2,
  ZAR: 18.5, THB: 35.5, MYR: 4.7, NZD: 1.65, HKD: 7.8, BDT: 110, NPR: 133, LKR: 300, PKR: 280 };
const DRIVERS = ["Rahul", "Amit", "Priya", "Suresh", "Neha", "Vikram", "Arjun", "Sana", "John", "Maria"];
const CARS = { Go: ["Maruti Swift Dzire", "Toyota Etios", "Hyundai Aura"], Premier: ["Honda City", "Toyota Camry", "Skoda Slavia"],
  XL: ["Toyota Innova Crysta", "Maruti Ertiga", "Kia Carens"], Auto: ["Bajaj RE Auto"], Moto: ["Honda Activa", "Hero Splendor"] };

// ---------- helpers ----------
const hav = (a, b) => { const R = 6371.0088, r = x => x * Math.PI / 180;
  const d1 = r(b.lat - a.lat), d2 = r(b.lon - a.lon);
  const h = Math.sin(d1 / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(d2 / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h)); };
const usdInr = () => (RATES && RATES.INR) || 83;
function curInfo() { const code = CUR[$("country").value] || "USD";
  let rate = (RATES && RATES[code]) || FALLBACK[code], src = RATES && RATES[code] ? "live" : "approx.";
  if (!rate) return { code: "USD", rate: 1, src: "no rate", sym: "$", dec: 2 };
  return { code, rate, src, sym: SYM[code] || code + " ", dec: ["JPY", "KRW", "IDR", "INR"].includes(code) ? 0 : 2 }; }
const fmt = (usd, c = curInfo()) => c.sym + (usd * c.rate).toLocaleString(undefined, { minimumFractionDigits: c.dec, maximumFractionDigits: c.dec });
const second = usd => curInfo().code === "INR" ? `$${usd.toFixed(2)} USD` : `₹${Math.round(usd * usdInr()).toLocaleString()} INR`;
function seeded(s) { let h = 2166136261; for (const ch of s) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); }
  return () => ((h = Math.imul(h ^ (h >>> 15), 2246822507) >>> 0) / 4294967296); }

// ---------- model + pricing ----------
const mlFare = km => Math.max(M.base_fare + M.rate_per_km * km, 0);       // trained model (USD)
function traffic(d) { const h = d.getHours(), wk = d.getDay() > 0 && d.getDay() < 6;
  if (wk && [8, 9, 10, 17, 18, 19, 20].includes(h)) return ["🔴 Heavy", 0.3, 1.35];
  if (h >= 7 && h <= 21) return ["🟡 Moderate", 0.1, 1.0]; return ["🟢 Light", 0, 0.9]; }
function cityPrice(ml, d, weather, tr, airport) {
  const h = d.getHours(), rush = [7, 8, 9, 16, 17, 18, 19].includes(h), night = h >= 23 || h < 5;
  const wkEve = (d.getDay() === 0 || d.getDay() === 6) && h >= 18;
  let surge = 1 + (rush ? 0.3 : 0) + (wkEve ? 0.2 : 0) + weather[1] + tr[1]; surge = Math.min(Math.round(surge * 10) / 10, 2.5);
  const sAmt = ml * (surge - 1), nAmt = night ? (ml + sAmt) * 0.25 : 0, aAmt = airport ? 3 : 0, book = 1;
  const sub = ml + sAmt + nAmt + aAmt + book, tax = sub * 0.05;
  return { surge, night, rush, total: sub + tax, lines: [["ML trip fare (model)", ml], [`Surge ${surge}×`, sAmt], ["Night charge 25%", nAmt], ["Airport fee", aAmt], ["Booking fee", book], ["GST 5%", tax]] }; }
function interPrice(ride, km, etaMin, d) {
  const inr = usdInr(), days = Math.max(1, Math.ceil(etaMin / 60 / 10)), bill = Math.max(km, 250 * days);
  const base = bill * OUT_INR[ride], allow = 300 * days, tolls = km * 1.6, night = (d.getHours() >= 22 || d.getHours() < 6) ? base * 0.1 : 0;
  const sub = base + allow + tolls + night, tax = sub * 0.05;
  return { surge: 1, night: night > 0, rush: false, total: (sub + tax) / inr, lines: [[`Outstation fare (${Math.round(bill)} km × ₹${OUT_INR[ride]}/km)`, base / inr],
    [`Driver allowance (${days} day${days > 1 ? "s" : ""})`, allow / inr], ["Estimated tolls", tolls / inr], ["Night charge 10%", night / inr], ["GST 5%", tax / inr]] }; }

// ---------- data ----------
async function loadData() {
  const [p, c] = await Promise.all([fetch("/data/places.json").then(r => r.json()), fetch("/data/currencies.json").then(r => r.json())]);
  PLACES = p.map(x => ({ name: x[0], country: x[1], lat: x[2], lon: x[3], lm: x[4] })); CUR = c;
  const countries = [...new Set(PLACES.map(x => x.country))].sort();
  $("country").innerHTML = countries.map(x => `<option${x === "India" ? " selected" : ""}>${x}</option>`).join("");
  fetch("https://open.er-api.com/v6/latest/USD").then(r => r.json()).then(j => { RATES = j.rates; render(); }).catch(() => {});
  fetch("/api/config").then(r => r.json()).then(j => { AI_ON = j.ai; $("aiBadge").textContent = AI_ON ? "✨ Gemini AI on" : "🤖 ML fare estimator"; }).catch(() => {});
  setDefaults(); }
function setDefaults() {
  const c = $("country").value, find = n => PLACES.find(x => x.country === c && x.name === n);
  const D = { India: ["Hawa Mahal, Jaipur", "Jaipur International Airport"], "United States": ["New York City", "Brooklyn"] }[c];
  pickup = D ? find(D[0]) || null : null; dropoff = D ? find(D[1]) || null : null;
  $("pickup").value = pickup ? pickup.name : ""; $("dropoff").value = dropoff ? dropoff.name : "";
  quote = null; drawMap(); $("rides").innerHTML = ""; ["trip", "ai", "best"].forEach(i => $(i).innerHTML = ""); }

// ---------- autocomplete ----------
function wireAC(inputId, listId, set) {
  const inp = $(inputId), list = $(listId); let idx = -1, items = [];
  const show = () => { const q = inp.value.trim().toLowerCase(), c = $("country").value;
    items = PLACES.filter(x => x.country === c && (!q || x.name.toLowerCase().includes(q)))
      .sort((a, b) => b.lm - a.lm || (a.name.toLowerCase().startsWith(q) ? -1 : 1)).slice(0, 40);
    list.innerHTML = items.map((x, i) => `<div data-i="${i}">${x.lm ? "⭐" : "🏙️"} ${x.name}<small> · ${x.country}</small></div>`).join("") ||
      `<div class="muted">No match in ${c}</div>`;
    list.style.display = "block"; idx = -1; };
  inp.addEventListener("input", show); inp.addEventListener("focus", show);
  inp.addEventListener("keydown", e => { const els = list.querySelectorAll("div[data-i]");
    if (e.key === "ArrowDown") idx = Math.min(idx + 1, els.length - 1); else if (e.key === "ArrowUp") idx = Math.max(idx - 1, 0);
    else if (e.key === "Enter" && idx >= 0) { pick(items[idx]); e.preventDefault(); return; } else return;
    els.forEach((el, i) => el.classList.toggle("on", i === idx)); e.preventDefault(); });
  list.addEventListener("mousedown", e => { const d = e.target.closest("div[data-i]"); if (d) pick(items[+d.dataset.i]); });
  inp.addEventListener("blur", () => setTimeout(() => list.style.display = "none", 150));
  function pick(x) { set(x); inp.value = x.name; list.style.display = "none"; quote = null; drawMap(); } }

// ---------- map (Leaflet + free CARTO dark tiles, no API key) ----------
function initMap() {
  map = L.map("map", { zoomControl: true }).setView([22.5, 78.9], 4);
  L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", { maxZoom: 19, subdomains: "abcd",
    attribution: "&copy; OpenStreetMap &copy; CARTO" }).addTo(map);
  layer = L.layerGroup().addTo(map); }
function drawMap(path) {
  if (!map) return; layer.clearLayers(); const pts = [];
  if (pickup && dropoff) { const ll = path ? path.map(c => [c[1], c[0]]) : [[pickup.lat, pickup.lon], [dropoff.lat, dropoff.lon]];
    L.polyline(ll, { color: "#06C167", weight: 5, opacity: .95, dashArray: path ? null : "8 8" }).addTo(layer); pts.push(...ll); }
  [[pickup, "#06C167", "Pickup"], [dropoff, "#ffffff", "Drop-off"]].forEach(([p, col, lab]) => { if (!p) return;
    L.circleMarker([p.lat, p.lon], { radius: 9, color: "#000", weight: 3, fillColor: col, fillOpacity: 1 }).bindTooltip(`${lab}: ${p.name}`).addTo(layer);
    pts.push([p.lat, p.lon]); });
  if (pts.length > 1) map.fitBounds(pts, { padding: [40, 40] }); else if (pts.length) map.setView(pts[0], 12);
  setTimeout(() => map.invalidateSize(), 50); }

async function route(a, b) {
  try { const ctl = new AbortController(); setTimeout(() => ctl.abort(), 7000);
    const r = await fetch(`https://router.project-osrm.org/route/v1/driving/${a.lon},${a.lat};${b.lon},${b.lat}?overview=full&geometries=geojson`, { signal: ctl.signal });
    const j = await r.json(); if (j.code !== "Ok") return null; const x = j.routes[0];
    return { km: x.distance / 1000, min: x.duration / 60, path: x.geometry.coordinates }; } catch { return null; } }
async function weatherAt(p, d) {
  if (Math.abs(d - new Date()) > 2 * 3600e3) return ["☀️ Clear", 0, 1, null, "assumed (future trip)"];
  try { const j = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${p.lat}&longitude=${p.lon}&current=weather_code,temperature_2m`).then(r => r.json());
    const c = j.current.weather_code, t = j.current.temperature_2m;
    return c >= 95 ? ["⛈️ Storm", 0.6, 1.4, t, "live"] : c >= 51 ? ["🌧️ Rain", 0.3, 1.2, t, "live"] : ["☀️ Clear", 0, 1, t, "live"];
  } catch { return ["☀️ Clear", 0, 1, null, "assumed (offline)"]; } }

// ---------- quote ----------
function when() { if ($("when").value === "now") return new Date();
  const d = new Date($("date").value + "T" + $("time").value); return isNaN(d) ? new Date() : d; }
async function getQuote() {
  if (!pickup || !dropoff) return alert("Please choose a pickup and a drop-off place.");
  if (pickup.lat === dropoff.lat && pickup.lon === dropoff.lon) return alert("Pickup and drop-off are the same place.");
  $("go").textContent = "Finding the best route…"; $("go").disabled = true;
  const d = when(), straight = hav(pickup, dropoff);
  const [rt, w] = await Promise.all([route(pickup, dropoff), weatherAt(pickup, d)]);
  const km = rt ? rt.km : straight * (straight > 20 ? 1.25 : 1.3), tr = traffic(d);
  const eta = (rt ? rt.min : km / (km <= 20 ? 25 : 55) * 60) * w[2] * tr[2];
  const intercity = km > 20, airport = /airport/i.test(pickup.name + dropoff.name), riders = +$("riders").value;
  const q = {}; for (const [n, v] of Object.entries(RIDES)) { if (v[1] < riders || (intercity && NO_INTERCITY.includes(n))) continue;
    q[n] = intercity ? interPrice(n, km, eta, d) : cityPrice(mlFare(km) * v[0], d, w, tr, airport); }
  if (!q[chosen]) chosen = Object.keys(q)[0];
  quote = { d, km, straight, rt, w, tr, eta, intercity, airport, riders, q };
  $("go").textContent = "See prices"; $("go").disabled = false; drawMap(rt && rt.path); render(); }

function render() {
  if (!quote) return; const Q = quote, c = curInfo(), rng = seeded(pickup.name + dropoff.name);
  const away = Object.fromEntries(Object.keys(RIDES).map(n => [n, 2 + Math.floor(rng() * 8)]));
  $("rides").innerHTML = `<h3 class="sec">Choose a ride</h3>` + Object.entries(Q.q).map(([n, p]) =>
    `<div class="ride${n === chosen ? " on" : ""}" data-r="${n}"><span class="ic">${RIDES[n][2]}</span>
      <div><div class="nm">${n} · 👤 ${RIDES[n][1]}${p.surge > 1 ? ` · ⚡${p.surge}×` : ""}</div><small>${away[n]} min away · ${RIDES[n][3]}</small></div>
      <div class="pr">${fmt(p.total)}<small>${second(p.total)}</small></div></div>`).join("") +
    `<button class="btn" id="req">Request ${chosen}</button><div id="driver"></div>
     <details class="card"><summary><b>🧾 Fare breakdown</b></summary><table>${Q.q[chosen].lines.filter(l => Math.abs(l[1]) > .004)
       .map(l => `<tr><td>${l[0]}</td><td class="n">${fmt(l[1])}</td><td class="n">₹${Math.round(l[1] * usdInr()).toLocaleString()}</td></tr>`).join("")}
       <tr class="win"><td>Total</td><td class="n">${fmt(Q.q[chosen].total)}</td><td class="n">₹${Math.round(Q.q[chosen].total * usdInr()).toLocaleString()}</td></tr></table>
       <p class="muted">${Q.intercity ? "Intercity trip: outstation tariff rule (illustrative), not the ML model." : "The ML model predicts the trip fare; ride type, surge, fees and tax are business rules on top."}</p></details>
     ${Q.riders > 1 ? `<p class="muted">👥 Split ${Q.riders} ways: <b>${fmt(Q.q[chosen].total / Q.riders)}</b> each</p>` : ""}`;
  document.querySelectorAll(".ride").forEach(el => el.onclick = () => { chosen = el.dataset.r; render(); });
  $("req").onclick = () => { const r = seeded(pickup.name + dropoff.name + chosen), dr = DRIVERS[Math.floor(r() * DRIVERS.length)];
    const plate = ["DL", "MH", "KA", "TS", "TN", "RJ"][Math.floor(r() * 6)] + " " + String(1 + Math.floor(r() * 20)).padStart(2, "0") + " " +
      "ABCDEFGH"[Math.floor(r() * 8)] + "JKLMNPRS"[Math.floor(r() * 8)] + " " + (1000 + Math.floor(r() * 9000));
    $("driver").innerHTML = `<div class="card"><div class="muted">Your driver is on the way · arriving in <b>${away[chosen]} min</b> (demo)</div>
      <div class="drv" style="margin-top:10px"><div class="av">${dr[0]}</div><div><b>${dr} · ⭐ ${(4.6 + r() * .38).toFixed(2)}</b>
      <div class="muted">${CARS[chosen][Math.floor(r() * CARS[chosen].length)]}</div></div><span class="plate">${plate}</span></div></div>`; };

  const P = Q.q[chosen], tot = P.total, mae = M.metrics.MAE * (tot / Math.max(P.lines[0][1], .01));
  const lo = Q.intercity ? tot * .9 : Math.max(tot - mae, 0), hi = Q.intercity ? tot * 1.15 : tot + mae;
  const drop = new Date(Q.d.getTime() + Q.eta * 60000);
  $("trip").innerHTML = `<div class="card"><div class="flex"><div class="grow"><div class="tl">
      <div class="a">${pickup.name}<small>${Q.d.toLocaleString([], { weekday: "short", day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}</small></div>
      <div class="b">${dropoff.name}<small>Drop-off ≈ ${drop.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</small></div></div></div>
      <div class="r"><div class="muted">${chosen} · ${Q.riders} rider${Q.riders > 1 ? "s" : ""}</div><div class="fare">${fmt(tot)}</div>
      <div class="fare2">${second(tot)}</div><div class="muted">Likely ${fmt(lo)} – ${fmt(hi)}</div></div></div>
    <span class="chip">🛣️ ${Q.km.toFixed(1)} km ${Q.rt ? "road" : "est. road"}</span><span class="chip">⏱️ ${Q.rt ? "" : "~"}${Math.round(Q.eta)} min</span>
    <span class="chip">${Q.w[0]}${Q.w[3] != null ? " " + Math.round(Q.w[3]) + "°C" : ""}</span><span class="chip">${Q.tr[0]} traffic</span>
    ${P.surge > 1 ? `<span class="chip g">⚡ ${P.surge}× surge</span>` : `<span class="chip">✅ No surge</span>`}
    ${P.night ? `<span class="chip">🌙 Night</span>` : ""}${Q.airport ? `<span class="chip">✈️ Airport</span>` : ""}${Q.intercity ? `<span class="chip w">🛣️ Intercity tariff</span>` : ""}
    <p class="muted">📡 Weather ${Q.w[4]} · traffic from time & day · 💱 1 USD = ${c.rate.toFixed(2)} ${c.code} (${c.src})${Q.rt ? "" : " · route service unavailable, using straight line × road factor"}</p>
    ${Q.intercity ? `<p class="muted">🛣️ The ML model was trained on city trips up to ${M.max_train_km} km, so this price uses an intercity tariff rule (per-km outstation rate, 250 km/day minimum, driver allowance, tolls, GST). Values are illustrative.</p>` : ""}</div>`;

  if (!Q.intercity) { const hrs = [...Array(24).keys()].map(h => { const d2 = new Date(Q.d); d2.setHours(h, 0, 0, 0);
      return cityPrice(mlFare(Q.km) * RIDES[chosen][0], d2, Q.w, traffic(d2), Q.airport).total; });
    const mn = Math.min(...hrs), mx = Math.max(...hrs), bi = hrs.indexOf(mn);
    $("best").innerHTML = `<div class="card"><b>⏰ Best time to ride today</b><div class="hb">${hrs.map((v, i) =>
      `<div class="${i === bi ? "best" : ""}" title="${String(i).padStart(2, "0")}:00 · ${fmt(v)}" style="height:${20 + 80 * (v - mn) / Math.max(mx - mn, .01)}%"></div>`).join("")}</div>
      <p class="muted">Cheapest at <b>${String(bi).padStart(2, "0")}:00</b> (≈ ${fmt(mn)}) · save up to ${fmt(mx - mn)} vs the priciest hour.</p></div>`;
    Q.cheapest = String(bi).padStart(2, "0") + ":00"; } else $("best").innerHTML = "";
  aiTip(); }

let aiTimer;
function aiTip() { clearTimeout(aiTimer); aiTimer = setTimeout(async () => {
  const Q = quote, P = Q.q[chosen]; $("ai").innerHTML = `<div class="card muted">✨ Getting trip tips…</div>`;
  try { const j = await fetch("/api/insight", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ from: pickup.name, to: dropoff.name, km: Q.km, ride: chosen, fare: fmt(P.total), hour: Q.d.getHours(), surge: P.surge,
        intercity: Q.intercity, weather: Q.w[0], night: P.night, cheapest_hour: Q.cheapest, rate: fmt(M.rate_per_km) }) }).then(r => r.json());
    $("ai").innerHTML = `<div class="card"><b>${j.source.startsWith("gemini") ? "✨ AI trip tips (Gemini)" : "💡 Trip tips"}</b><p>${j.text}</p></div>`;
  } catch { $("ai").innerHTML = ""; } }, 600); }

// ---------- model report ----------
function report() { const m = M.metrics;
  $("report").innerHTML = `<div class="grid2"><div class="card"><div class="muted">Model picked</div><div class="fare" style="font-size:1.6rem">🏆 ${M.name}</div>
    <p class="muted">fare = $${M.base_fare} + $${M.rate_per_km} × km · trained on ${M.rows.toLocaleString()} completed trips · tested on ${M.test_rows.toLocaleString()}</p>
    <table><tr><th>Model</th><th class="n">MAE</th><th class="n">RMSE</th><th class="n">R²</th></tr>${M.comparison.map(r =>
      `<tr class="${r[0].includes("final") ? "win" : ""}"><td>${r[0]}</td><td class="n">${r[1].toFixed(2)}</td><td class="n">${r[2].toFixed(2)}</td><td class="n">${r[3].toFixed(3)}</td></tr>`).join("")}</table>
    <p class="muted">* earlier training run. Same test set (80/20, random_state=42). Train R² ${m.Train_R2} vs test ${m.R2}: no overfitting. CV RMSE ${m.CV_RMSE}.</p></div>
    <div class="card"><b>What drives the fare</b><div class="bars">${Object.entries(M.importance).map(([k, v]) =>
      `<div>${k} <span class="muted">${v}%</span><div class="bar"><i style="width:${Math.max(v, 1)}%"></i></div></div>`).join("")}</div>
    <p class="muted">MAE = average error ($) · RMSE = punishes big misses · R² = share of variation explained. ${m.within_2}% of test trips within $2.</p></div></div>`; }

// ---------- init ----------
function initSchedule() { const ds = [...Array(31).keys()].map(k => { const d = new Date(); d.setDate(d.getDate() + k); return d; });
  $("date").innerHTML = ds.map((d, k) => `<option value="${d.toISOString().slice(0, 10)}">${k === 0 ? "📅 Today" : k === 1 ? "📅 Tomorrow" : "📅 " + d.toDateString().slice(0, 10)}</option>`).join("");
  const ts = []; for (let h = 0; h < 24; h++) for (const m of [0, 15, 30, 45]) ts.push(`${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`);
  $("time").innerHTML = ts.map(t => `<option>${t}</option>`).join("");
  const n = new Date(); n.setMinutes(Math.ceil(n.getMinutes() / 15) * 15); $("time").value = `${String(n.getHours()).padStart(2, "0")}:${String(n.getMinutes() % 60).padStart(2, "0")}`;
  $("when").onchange = () => { $("schedRow").hidden = $("when").value === "now"; quote = null; }; }

document.addEventListener("DOMContentLoaded", async () => {
  initMap(); initSchedule(); report();
  wireAC("pickup", "pickupList", x => pickup = x); wireAC("dropoff", "dropoffList", x => dropoff = x);
  $("country").onchange = setDefaults; $("go").onclick = getQuote;
  ["riders", "payment", "date", "time"].forEach(i => $(i).onchange = () => { if (quote) getQuote(); });
  await loadData(); });
