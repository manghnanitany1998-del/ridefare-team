# 🚕 RideFare: ML Uber Fare Predictor

Predict a ride fare at booking time anywhere in the world. The model is trained on **42,540 real completed Uber trips**.
Dark Uber-style web app, interactive map, 34,000+ places (85 Indian landmarks), local currency + ₹, intercity pricing,
and optional **Google Gemini** trip tips. Deploys free on **Vercel**.

## Team
- Tanya Manghnani
- _Teammate 2_
- _Teammate 3_

## Results (same 80/20 split, random_state=42, 8,508 test trips)
| Model | MAE | RMSE | R² |
|---|---|---|---|
| Predict the average | 4.96 | 6.21 | 0.00 |
| **Linear Regression on distance_km (final)** | **2.49** | **3.10** | **0.750** |
| Linear Regression (all features) | 2.49 | 3.10 | 0.750 |
| Hist Gradient Boosting* | 2.52 | 3.15 | 0.747 |
| XGBoost* | 2.54 | 3.17 | 0.744 |
| Random Forest* | 2.60 | 3.27 | 0.727 |

\* earlier training run; the notebook re-runs all models and writes `reports/results.csv`.

**Final model:** `fare = $2.97 + $1.86 × distance_km`. It ties the baseline: no booking-time feature adds signal beyond distance.
Train R² 0.76 vs test 0.75 (no overfitting).

## Project structure
```
public/                 web app (static, free on Vercel)
  index.html, styles.css, app.js
  model.js              final model coefficients + metrics (from the notebook)
  data/places.json      34,361 places · data/currencies.json  251 countries
api/
  insight.js            Gemini trip tips (server-side, key from env)
  config.js             tells the page if AI is on (never exposes the key)
ml/                     notebook, training data and saved model (not deployed)
  notebooks/Uber_Fare_Prediction.ipynb
  app/app.py            Streamlit version of the app
  models/               uber_fare_model.pkl (created by the notebook)
.env.example            copy to .env and paste GEMINI_API_KEY
vercel.json             Vercel config
```

## Run the website locally
Easiest: any static server.
```bash
cd public && python -m http.server 8000      # open http://localhost:8000
```
AI tips use built-in rules here. To test Gemini locally:
```bash
npm i -g vercel
cp .env.example .env      # paste your GEMINI_API_KEY
vercel dev                # http://localhost:3000
```

## Deploy free on Vercel (Hobby plan)
1. Push this folder to GitHub.
2. vercel.com → **Add New → Project** → import the repo. Framework preset: **Other**. No build command. Output: leave default.
3. **Settings → Environment Variables** → add `GEMINI_API_KEY` (and optionally `GEMINI_MODEL`, `GEMINI_MAX_TOKENS`, `AI_RATE_LIMIT_PER_MIN`).
4. **Deploy**. Every `git push` redeploys automatically.

## Cost optimisation (Gemini)
- Uses **gemini-2.5-flash-lite** (cheapest text model), max **120 output tokens**, ~60-token prompt.
- Called **once per quote**, debounced, **cached 6 h** per similar trip, **rate-limited** to 6 calls/min per user.
- Key stays on the server; with no key the app uses free built-in tips.
- Fare prediction, maps and search run in the browser: **0 server cost**.

## Maps & external services (all free, no keys)
| Feature | Service | If blocked |
|---|---|---|
| Dark map tiles | CARTO + OpenStreetMap (Leaflet) | grey map background, markers still shown |
| Road distance | OSRM public router | straight line × 1.25 road factor |
| Weather | Open-Meteo | assumed clear |
| Exchange rates | open.er-api.com | built-in approximate rates |

## Retrain the model
```bash
cd ml
python -m venv venv && source venv/Scripts/activate
pip install -r requirements.txt
jupyter notebook notebooks/Uber_Fare_Prediction.ipynb     # Kernel → Restart & Run All
```
Then copy `base_fare` and `rate_per_km` from `reports/results.json` into `public/model.js`.

## Notes
Ride types, surge, fees, GST and the intercity tariff are illustrative business rules, not learned from data.
Place data: GeoNames (CC BY 4.0). Maps: © OpenStreetMap, © CARTO.
